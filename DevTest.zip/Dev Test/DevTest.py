## Start Time of File: 3:41 PM
## Stop Time of File: 5:49 PM
## Thoughts:
##  - For some reason, despite having code to remove "Grade" from the csv file read, it still came up in the actual code.
##  - Overall_Class.txt does not return the highest grade nor the average for all students despite each individual Class
##    .txt file successfully calculating the grades (this is why I made sure to have those output
##    as well, since abnormalities can come up).
##  - Redundancy of variable declaration certainly not needed but wanted to ensure I could reference those values in
##    overall_calc function. Definitely a better way to do it (and that works, since I presume that is the root of my pro-
##    blem with the program outputting 0 in that specific .txt file.
##  - Attempted to do individual class files but unsure if I could implement it in the 1-3 hour window, which I wanted to
##    adhere to.
##  - If I had more time, I would certainly add/do:
##      + Exception handling
##      + Checking for illegal values (grade of A instead of a number)
##      + Streamlining of code to be more efficient and less redundant
##      + Way to detect weird characters (see issue referenced in read_csv_C()
##      + More in-depth comments, for sure
##      + Not have all of the code in one massive file, segment it into different files and import those into other files
##        as needed
##      + Figure out how to "output in a prominent way" (more expression? more characters?)

# Library imports
import csv
import io

# Arrays to store each student's name for each class
name_A = []
name_B = []
name_C = []

# Arrays to store each student's grade for each class
grade_A = []
grade_B = []
grade_C = []

# Declaring necessary variables (Class A)
namesA = [] # Keeps track of students removed from calculation
students_usedA = 0 # Keeps track of students used for calculation
avg_scoreA = 0 # Tracks the average score for the class
class_sizeA = 0 # Keeps track of the total class size

# Declaring necessary variables (Class B)
namesB = [] # Keeps track of students removed from calculation
students_usedB = 0 # Keeps track of students used for calculation
avg_scoreB = 0 # Tracks the average score for the class
class_sizeB = 0 # Keeps track of the total class size

# Declaring necessary variables (Class C)
namesC = [] # Keeps track of students removed from calculation
students_usedC = 0 # Keeps track of students used for calculation
avg_scoreC = 0 # Tracks the average score for the class
class_sizeC = 0 # Keeps track of the total class size

# Designating the files to be imported
inFileA = "ClassA.csv"
inFileB = "ClassB.csv"
inFileC = "ClassC.csv"

def read_csv_A():
    # Reading the files
    with open(inFileA) as file:
        reader_A = csv.reader(file)

        # Looping through the file ClassA
        for row in reader_A:
            name_A.append(row[0])
            grade_A.append(row[1])

    # Conditional to ensure that "Student Name" and "Grade" are present
    if (name_A[0] == "Student Name" or grade_A[0] == "Grade"):
        name_A.remove(name_A[0])
        grade_A.remove(grade_A[0])
        #print(name_A)
        #print(grade_A)

def read_csv_B():
    with open(inFileB) as file:
        reader_B = csv.reader(file)

        # Looping through the file ClassB
        for row in reader_B:
            name_B.append(row[0])
            grade_B.append(row[1])
    # Conditional to ensure that "Student Name" and "Grade" are present
    if (name_B[0] == "Student Name" or grade_B[0] == "Grade"):
        name_B.remove(name_B[0])
        grade_B.remove(grade_B[0])
        #print(name_B)
        #print(grade_B)

def read_csv_C():
    with open(inFileC) as file:
        reader_C = csv.reader(file)

        # Looping through the file ClassC
        for row in reader_C:
            name_C.append(row[0])
            grade_C.append(row[1])

    # Conditional to ensure that "Student Name" and "Grade" are present
    # Issue encountered:
    # Student Name in this csv file returns "ï»¿Student Name" when read in, unsure how to fix.
    # Commented line of code is what would normally be used, uncommented is workaround.
    # if name_C[0] == "Student Name" and grade_C[0] == "Grade":
    if (name_C[0] == "Student Name" or grade_C[0] == "Grade"):
        name_C.remove(name_C[0])
        grade_C.remove(grade_C[0])
    #print(name_C)
    #print(grade_C)

def classA_calc():
    read_csv_A()

    namesA = []
    students_usedA = 0
    avg_scoreA = 0.0
    class_sizeA = 0

    for i in range(0, len(name_A), 1):
        if (grade_A[i] == str(0)):
            namesA.append(name_A[i])
            class_sizeA += 1
        elif (grade_A[i] == "Grade"):
            continue
        else:
            avg_scoreA += float(grade_A[i])
            class_sizeA += 1
            students_usedA += 1
    avg_scoreA = avg_scoreA/class_sizeA

    # print("Average score: " + str(avg_score))
    # print("Class size: " + str(class_size))
    # print("Students Used for Calculation: " + str(students_used))
    # print("Students discarded for grade of 0: " + str(names))

    file = open("ClassA.txt", "w")
    file.write("Average score: " + str(avg_scoreA.__round__(1)) + "\n")
    file.write("Class size: " + str(class_sizeA) + "\n")
    file.write("Students Used for Calculation: " + str(students_usedA) + "\n")
    file.write("Students discarded for grade of 0: " + str(namesA) + "\n")
    file.close()

def classB_calc():
    read_csv_B()

    namesB = []
    students_usedB = 0
    avg_scoreB = 0.0
    class_sizeB = 0

    # Looping over
    for i in range(0, len(name_B), 1):
        if (grade_B[i] == str(0)):
            namesB.append(name_B[i])
            class_sizeB += 1
        elif (grade_B[i] == "Grade"):
            continue
        else:
            avg_scoreB += float(grade_B[i])
            class_sizeB += 1
            students_usedB += 1
    avg_scoreB = avg_scoreB/class_sizeB

    # print("Average score: " + str(avg_score))
    # print("Class size: " + str(class_size))
    # print("Students Used for Calculation: " + str(students_used))
    # print("Students discarded for grade of 0: " + str(names))

    file = open("ClassB.txt", "w")
    file.write("Average score: " + str(avg_scoreB.__round__(1)) + "\n")
    file.write("Class size: " + str(class_sizeB) + "\n")
    file.write("Students Used for Calculation: " + str(students_usedB) + "\n")
    file.write("Students discarded for grade of 0: " + str(namesB) + "\n")
    file.close()

def classC_calc():
    read_csv_C()

    namesC = []
    students_usedC = 0
    avg_scoreC = 0.0
    class_sizeC = 0

    for i in range(0, len(name_C), 1):
        if (grade_C[i] == str(0)):
            namesC.append(name_C[i])
            class_sizeC += 1
        elif (grade_C[i] == "Grade"):
            continue
        else:
            avg_scoreC += float(grade_C[i])
            class_sizeC += 1
            students_usedC += 1
    avg_scoreC = avg_scoreC/class_sizeC

    # print("Average score: " + str(avg_score))
    # print("Class size: " + str(class_size))
    # print("Students Used for Calculation: " + str(students_used))
    # print("Students discarded for grade of 0: " + str(names))

    file = open("ClassC.txt", "w")
    file.write("Average score: " + str(avg_scoreC.__round__(1)) + "\n")
    file.write("Class size: " + str(class_sizeC) + "\n")
    file.write("Students Used for Calculation: " + str(students_usedC) + "\n")
    file.write("Students discarded for grade of 0: " + str(namesC) + "\n")
    file.close()

def overall_calc():
    classA_calc()
    classB_calc()
    classC_calc()

    file = open("Overall_Class.txt", "w")
    # Code to determine highest performing class
    if (avg_scoreA > avg_scoreB and avg_scoreA > avg_scoreC):
        file.write("Class A is the highest performing class with an average of " + str(avg_scoreC) + "! Congratulations!" + "\n")
    elif (avg_scoreB > avg_scoreA and avg_scoreB > avg_scoreC):
        file.write("Class B is the highest performing class with an average of " + str(avg_scoreB) + "! Congratulations!" + "\n")
    else:
        file.write("Class C is the highest performing class with an average of " + str(avg_scoreC) + "! Congratulations!" + "\n")

    # Code to get the average score for all students regardless of class
    overall_average = (avg_scoreA + avg_scoreB + avg_scoreC)/3

    file.write("The average score for all students regardless of their class was " + str(overall_average))
    file.close()

def main():
    overall_calc()

main()