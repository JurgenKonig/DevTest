from File_Read.py import *
import csv

def classB_calc():
    read_csv()

    # Declaring necessary variables
    names = []
    students_used = 0
    avg_score = 0
    class_size = 0

    # Looping over
    for i in range(0, len(name_B), 1):
        if (grade_B[i] == str(0)):
            names.append(name_B[i])
            class_size += 1
        else:
            avg_score.__add__(grade_B[i])
            class_size += 1
            students_used += 1
    avg_score = avg_score/class_size

    print("Average score: " + str(avg_score))
    print("Class size: " + str(class_size))
    print("Students Used for Calculation: " + str(students_used))
    print("Students discarded for grade of 0: " + str(names))

    # file = open("ClassB.txt", w)
    # file.write("Average score: " + str(avg_score))
    # file.write("Class size: " + str(class_size))
    # file.write("Students Used for Calculation: " + str(students_used))
    # file.write("Students discarded for grade of 0: " + str(names))
    # file.close()