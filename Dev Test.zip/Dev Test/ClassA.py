from File_Read import read_csv_A
from csv import *

def classA_calc():
    read_csv_A()

    names = []
    students_used = 0
    avg_score = 0
    class_size = 0
    for i in range(0, len(name_A), 1):
        if (grade_A[i] == str(0)):
            names.append(name_A[i])
            class_size += 1
        else:
            avg_score += float(grade_A[i])
            class_size += 1
            students_used += 1
    avg_score = avg_score/class_size

    # print("Average score: " + str(avg_score))
    # print("Class size: " + str(class_size))
    # print("Students Used for Calculation: " + str(students_used))
    # print("Students discarded for grade of 0: " + str(names))

    file = open("ClassA.txt", "w")
    file.write("Average score: " + str(avg_score) + "\n")
    file.write("Class size: " + str(class_size) + "\n")
    file.write("Students Used for Calculation: " + str(students_used) + "\n")
    file.write("Students discarded for grade of 0: " + str(names) + "\n")
    file.close()

classA_calc()